EasyOS Repair Center - Phase 1
by pp4mnk

This is the first large functional expansion of EasyOS Repair Center.
It provides 55+ safe diagnostic, repair and maintenance utilities for EasyOS.

INSTALLATION

  tar -xzf easyos-repair-center-pp4mnk-v1.2-phase1.tar.gz
  cd easyos-repair-center-pp4mnk-v1.2-phase1
  chmod +x install.sh
  ./install.sh

RUN

  easyos-repair-center

or open:

  Menu -> System -> EasyOS Repair Center

WHAT IT DOES

- First Aid: health check, bug report, safe one-click repair
- Desktop: JWM, ROX, menus, icons, GTK, wallpaper and Xorg reports
- Fonts: font cache, installed fonts, LibreOffice font substitutes
- Network: DHCP/network restart, DNS repair, ping, gateway and WiFi info
- Browsers: Firefox/Chromium locks, Opera root/no-sandbox help, caches, certificates
- Cleanup: temp files, thumbnails and old logs
- RAM: memory status, clear cache, zram, top processes
- Storage: filesystem info, mounted drives, SMART, TRIM and largest folders
- Permissions: common permissions and executable flags
- EasyOS-specific: save layer, whiteouts, copy-to-RAM, boot flags, SFS, portable apps, containers and snapshots info
- Audio and printers: ALSA/PulseAudio info, CUPS status, queue cleaning
- Performance and security: quick benchmark and basic checks

NOTES

Most actions are conservative and safe. Destructive repairs are avoided in Phase 1.
Logs are saved in /root/easyos-repair-center-logs.

Designed and developed by pp4mnk.
