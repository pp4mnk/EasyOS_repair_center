#!/bin/sh
rm -rf /usr/local/easyos-repair-center
rm -f /usr/local/bin/easyos-repair-center
rm -f /usr/share/applications/easyos-repair-center.desktop
rm -f /usr/share/pixmaps/easyos-repair-center.svg
fixmenus 2>/dev/null || true
jwm -restart 2>/dev/null || true
echo "EasyOS Repair Center removed."
