#!/bin/sh
set -e
APPDIR=/usr/local/easyos-repair-center
mkdir -p "$APPDIR" /usr/local/bin /usr/share/applications /usr/share/pixmaps
cp -a usr/local/easyos-repair-center/easyos-repair-center "$APPDIR/"
chmod 755 "$APPDIR/easyos-repair-center"
ln -sf "$APPDIR/easyos-repair-center" /usr/local/bin/easyos-repair-center
cp -a usr/share/applications/easyos-repair-center.desktop /usr/share/applications/
cp -a usr/share/pixmaps/easyos-repair-center.svg /usr/share/pixmaps/
chmod 644 /usr/share/applications/easyos-repair-center.desktop /usr/share/pixmaps/easyos-repair-center.svg
fixmenus 2>/dev/null || true
jwm -restart 2>/dev/null || true
echo "EasyOS Repair Center Phase 1 installed."
echo "Run: easyos-repair-center"
echo "Menu: System -> EasyOS Repair Center"
