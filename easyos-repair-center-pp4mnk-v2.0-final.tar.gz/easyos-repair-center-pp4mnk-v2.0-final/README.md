# EasyOS Repair Center v2.0 Final
### by pp4mnk

EasyOS Repair Center is a full maintenance, repair, diagnostic and recovery suite for EasyOS.

This final phase includes 184 utilities grouped into practical modules:

- Doctor and reports
- Network, DNS, DHCP, WiFi and Ethernet
- Browsers and portable applications
- Desktop, JWM, ROX, icons and GTK
- Fonts, audio and printers
- Storage, filesystem, permissions and cleanup
- EasyOS-specific tools: save layer, overlays, whiteouts, SFS, snapshots, containers, boot flags and copy-to-RAM checks
- Performance, security, emergency recovery and developer tools

## Installation

```bash
tar -xzf easyos-repair-center-pp4mnk-v2.0-final.tar.gz
cd easyos-repair-center-pp4mnk-v2.0-final
chmod +x install.sh
./install.sh
```

## Launch

```bash
easyos-repair-center
```

Or use: Menu -> System -> EasyOS Repair Center

## Installed files

- /usr/local/bin/easyos-repair-center
- /usr/share/applications/easyos-repair-center.desktop

## Author

Designed, developed and documented by pp4mnk.
