#!/bin/sh
set -e
cp -a files/* /
chmod 755 /usr/local/bin/easyos-repair-center
[ -x /usr/sbin/fixmenus ] && /usr/sbin/fixmenus || true
[ -x /usr/bin/update-desktop-database ] && update-desktop-database /usr/share/applications 2>/dev/null || true
[ -x /usr/bin/jwm ] && jwm -restart 2>/dev/null || true
echo "EasyOS Repair Center v2.0 Final installed."
echo "Run: easyos-repair-center"
echo "Menu: System -> EasyOS Repair Center"
