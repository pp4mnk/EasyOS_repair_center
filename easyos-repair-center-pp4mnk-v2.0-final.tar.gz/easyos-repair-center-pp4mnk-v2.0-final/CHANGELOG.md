# Changelog

## v2.0 Final
- Expanded to 184 utilities.
- Added EasyOS-specific modules for save layer, overlays, whiteouts, snapshots, containers, SFS, boot flags and copy-to-RAM.
- Added bug report generator for forum support.
- Added emergency recovery and developer sections.
- Improved menu organization.
- Added safer confirmations for maintenance actions.

## v1.3 Phase 2
- 100 utilities.

## v1.2 Phase 1
- 55+ utilities.
