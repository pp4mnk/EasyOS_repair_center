#!/bin/sh
rm -f /usr/local/bin/easyos-repair-center
rm -f /usr/share/applications/easyos-repair-center.desktop
[ -x /usr/sbin/fixmenus ] && /usr/sbin/fixmenus || true
[ -x /usr/bin/jwm ] && jwm -restart 2>/dev/null || true
echo "EasyOS Repair Center removed."
