#!/bin/sh
set -e
mkdir -p /usr/local/bin /usr/share/applications
cp -f files/usr/local/bin/easyos-repair-center /usr/local/bin/easyos-repair-center
chmod 755 /usr/local/bin/easyos-repair-center
cat > /usr/share/applications/easyos-repair-center.desktop <<'DESK'
[Desktop Entry]
Type=Application
Name=EasyOS Repair Center
GenericName=EasyOS maintenance and repair tools
Comment=100 diagnostics, repair and maintenance utilities for EasyOS - by pp4mnk
Exec=easyos-repair-center
Icon=applications-system
Terminal=false
Categories=System;Utility;
DESK
fixmenus 2>/dev/null || true
jwm -restart 2>/dev/null || true
echo "EasyOS Repair Center v1.3 Phase 2 installed. Run: easyos-repair-center"
