#!/bin/sh
rm -f /usr/local/bin/easyos-repair-center
rm -f /usr/share/applications/easyos-repair-center.desktop
fixmenus 2>/dev/null || true
jwm -restart 2>/dev/null || true
echo "EasyOS Repair Center removed."
