EasyOS Repair Center v1.3 Phase 2
Designed and developed by pp4mnk

This version includes 100 utilities for EasyOS maintenance, diagnostics and repair.
It focuses on common difficulties for new users: Internet, DNS, browsers, desktop,
fonts, audio, printers, storage, permissions, RAM, boot flags, save layer, SFS,
snapshots, containers and bug reports.

Install:
  tar -xzf easyos-repair-center-pp4mnk-v1.3-phase2.tar.gz
  cd easyos-repair-center-pp4mnk-v1.3-phase2
  chmod +x install.sh
  ./install.sh

Run:
  easyos-repair-center

Menu:
  Menu -> System -> EasyOS Repair Center

Notes:
- Safe information tools run directly.
- Repair/cleanup actions ask confirmation first.
- Reports are saved in /root.
- Logs are saved in /tmp/easyos-repair-center.
