#!/bin/sh
set -e
APPDIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cp -a "$APPDIR/usr/local/easyos-repair-center" /usr/local/
ln -sf /usr/local/easyos-repair-center/easyos-repair-center /usr/local/bin/easyos-repair-center
cp -a "$APPDIR/usr/share/applications/easyos-repair-center.desktop" /usr/share/applications/
cp -a "$APPDIR/usr/share/pixmaps/easyos-repair-center.svg" /usr/share/pixmaps/
chmod +x /usr/local/easyos-repair-center/easyos-repair-center /usr/local/bin/easyos-repair-center
[ -x /usr/sbin/fixmenus ] && /usr/sbin/fixmenus || true
if command -v jwm >/dev/null 2>&1; then jwm -reload >/dev/null 2>&1 || true; fi
echo "EasyOS Repair Center installed. Run: easyos-repair-center"
echo "Menu: System -> EasyOS Repair Center"
