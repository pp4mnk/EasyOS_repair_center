EasyOS Repair Center v1.1-fixed-fixed
by pp4mnk

A lightweight repair and diagnostic center for EasyOS and Puppy-like systems.

Main idea:
- Give normal users one place to repair common problems.
- Keep everything simple, readable and shell-based.
- Provide diagnostic reports that can be pasted into the EasyOS/Puppy forum.

New in v1.1-fixed-fixed:
- Expanded menu with more than 35 utilities.
- Health summary.
- Full diagnostics report.
- Internet, DNS, DHCP and IP tools.
- Browser repairs, including Chromium root launcher fix.
- Desktop repairs: menu, icons, fonts, GTK, JWM, ROX.
- EasyOS save/layer report.
- Storage and SMART report when smartctl is installed.
- Boot, snapshot, Xorg, sound, printer and package-manager launchers when available.
- Cleanup, RAM cache and process reports.
- Backup folder for modified config files: /root/easyos-repair-center-backups

Install:

tar -xzf easyos-repair-center-pp4mnk-v1.1-fixed-fixed.tar.gz
cd easyos-repair-center-pp4mnk-v1.1-fixed-fixed
chmod +x install.sh
./install.sh

Run:

easyos-repair-center

Menu:

System -> EasyOS Repair Center

Uninstall:

./uninstall.sh

Notes:
- Some buttons only open existing EasyOS/Puppy tools if they are installed.
- The program avoids destructive repairs by default.
- Riskier operations ask for confirmation.
