#!/bin/sh
rm -rf /usr/local/easyos-repair-center
rm -f /usr/local/bin/easyos-repair-center
rm -f /usr/share/applications/easyos-repair-center.desktop
rm -f /usr/share/pixmaps/easyos-repair-center.svg
[ -x /usr/sbin/fixmenus ] && /usr/sbin/fixmenus || true
if command -v jwm >/dev/null 2>&1; then jwm -reload >/dev/null 2>&1 || true; fi
echo "EasyOS Repair Center removed."
