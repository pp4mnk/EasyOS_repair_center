EasyOS Repair Center by pp4mnk
Version 1.0

What is it?
-----------
EasyOS Repair Center is a lightweight repair and diagnostic tool for EasyOS and Puppy-like systems.
It gives normal users one simple place to fix common problems: menu, icons, fonts, GTK, DNS, browser cache, permissions, temporary files, RAM cache, storage checks and diagnostic reports.

Install
-------
tar -xzf easyos-repair-center-pp4mnk-v1.0.tar.gz
cd easyos-repair-center-pp4mnk-v1.0
chmod +x install.sh
./install.sh

Run
---
easyos-repair-center

Or use the menu:
Menu -> System -> EasyOS Repair Center

Uninstall
---------
cd easyos-repair-center-pp4mnk-v1.0
chmod +x uninstall.sh
./uninstall.sh

Notes
-----
This is an early v1.0. It is intentionally simple, readable and easy to extend.
Safe actions ask before deleting cache/temp files. Personal files are not removed.
Logs are saved to /tmp/easyos-repair-center.log
Reports are saved to /tmp/easyos-repair-center-report.txt
