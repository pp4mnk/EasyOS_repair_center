#!/bin/sh
# Installer for EasyOS Repair Center by pp4mnk

set -e

APPDIR="/usr/local/easyos-repair-center"
BIN="/usr/local/bin/easyos-repair-center"
DESKTOP="/usr/share/applications/easyos-repair-center.desktop"
ICON="/usr/share/pixmaps/easyos-repair-center.svg"

mkdir -p "$APPDIR" /usr/local/bin /usr/share/applications /usr/share/pixmaps

cp -af usr/local/easyos-repair-center/easyos-repair-center "$APPDIR/easyos-repair-center"
chmod 755 "$APPDIR/easyos-repair-center"
ln -sf "$APPDIR/easyos-repair-center" "$BIN"

cp -af usr/share/applications/easyos-repair-center.desktop "$DESKTOP"
chmod 644 "$DESKTOP"

cp -af usr/share/pixmaps/easyos-repair-center.svg "$ICON"
chmod 644 "$ICON"

if command -v fixmenus >/dev/null 2>&1; then
  fixmenus || true
fi
if command -v jwm >/dev/null 2>&1; then
  jwm -reload >/dev/null 2>&1 || true
fi

echo ""
echo "EasyOS Repair Center installed."
echo "Run it with: easyos-repair-center"
echo "Menu: System -> EasyOS Repair Center"
echo ""
