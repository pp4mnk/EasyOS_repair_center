#!/bin/sh
rm -rf /usr/local/easyos-repair-center
rm -f /usr/local/bin/easyos-repair-center
rm -f /usr/share/applications/easyos-repair-center.desktop
rm -f /usr/share/pixmaps/easyos-repair-center.svg
command -v fixmenus >/dev/null 2>&1 && fixmenus || true
command -v jwm >/dev/null 2>&1 && jwm -reload >/dev/null 2>&1 || true
echo "EasyOS Repair Center removed."
